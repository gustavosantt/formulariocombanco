// Captura o formulário pelo ID
const form = document.getElementById('usuarioForm');

// Adiciona o evento de "submit" ao formulário
form.addEventListener('submit', function(event) {
  event.preventDefault();  // Previne o comportamento padrão do formulário (recarga da página)

  // Obtém os valores dos campos do formulário
  const nome = document.getElementById('nome').value;
  const email = document.getElementById('email').value;
  const cpf = document.getElementById('cpf').value

  // Cria um objeto com os dados
  const dados = { nome, email };

  // Envia os dados para a API com o método POST
  fetch('http://localhost:3000/usuarios', {
    method: 'POST',  // Método POST
    headers: {
      'Content-Type': 'application/json'  // Tipo de dado que está sendo enviado
    },
    body: JSON.stringify(dados)  // Envia os dados como JSON
  })
  .then(response => response.json())
  .then(data => {
    alert('Usuário cadastrado com sucesso!');
    form.reset();  // Limpa o formulário após o envio
  })
  .catch(error => {
    console.error('Erro ao cadastrar usuário:', error);
    alert('Ocorreu um erro ao cadastrar o usuário');
  });
});
