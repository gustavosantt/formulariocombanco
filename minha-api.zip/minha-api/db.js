const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'sua_senha',
    database: 'formulario',
    port: 3307
});

// Conexão ao banco de dados
connection.connect((error) => {
    if (error) {
        console.log("Conexão falhou:", error);
    } else {
        console.log("Banco conectado");
    }
});

module.exports = connection;
