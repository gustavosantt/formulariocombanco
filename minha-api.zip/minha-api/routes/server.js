const express = require('express');
const cors = require('cors');
const app = express();
const usuariosRoutes = require('./usuarios');  



// Middleware
app.use(cors());
app.use(express.json());

// Rotas
app.use('/usuarios', usuariosRoutes);

// Iniciar servidor
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
