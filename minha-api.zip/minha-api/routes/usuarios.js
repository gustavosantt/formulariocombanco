const express = require('express');
const router = express.Router();
const db = require('../db');

// Rota GET para listar usuários
router.get('/', (req, res) => {
  db.query('SELECT * FROM usuarios', (err, results) => {
    if (err) {
      res.status(500).json({ error: 'Erro ao buscar usuários' });
    } else {
      res.json(results);
    }
  });
});

// Rota POST para adicionar novo usuário
router.post('/', (req, res) => {
  const { nome, email, cpf } = req.body;
  db.query('INSERT INTO usuarios (nome, email, cpf) VALUES (?, ?)', [nome, email, cpf], (err, result) => {
    if (err) {
      res.status(500).json({ error: 'Erro ao inserir usuário' });
    } else {
      res.status(201).json({ id: result.insertId, nome, email, cpf });
    }
  });
});

module.exports = router;
